Bicycle balancing/riding domain from https://github.com/amarack/python-rl.
From the paper:
Learning to Drive a Bicycle using Reinforcement Learning and Shaping.
Jette Randlov and Preben Alstrom. 1998.